const copyBtn = document.getElementById('copyPix')

copyBtn.addEventListener('click', () => {
  const pixKey = document.getElementById('pixKey').innerText

  navigator.clipboard.writeText(pixKey)

  copyBtn.innerText = 'PIX copiado!'

  setTimeout(() => {
    copyBtn.innerText = 'Copiar chave PIX'
  }, 2000)
})

const themeToggle = document.getElementById('themeToggle')

themeToggle.addEventListener('click', () => {
  document.body.classList.toggle('dark')

  themeToggle.innerHTML = document.body.classList.contains('dark')
    ? '☀️'
    : '🌙'
})
